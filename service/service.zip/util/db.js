module.exports = {
    mongodb: 'mongodb://root:123456@localhost/users',
};